package com.developerfinance.developerfinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeveloperfinanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
